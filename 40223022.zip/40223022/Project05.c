// Nazanin Zahra Taghizadeh 40223022
#include <stdio.h>
int main(void)
{
    printf("Hello welcome to this Project\n");
    printf("Please enter an integer number:\t");
    int n;
    scanf("%d",&n);
     char phrase[n+1];
     char inst[n+1];
     int j=0;
     int x=0;
     int q;
     int e=n;
    printf("Please write a phrase with lenght of %d :\t",n);
    scanf("%s",&phrase);
    printf("%s\n",phrase);
    int i=0;
    int s=0;
    int d;
    int m;
    for (d=0;d<(e-1);++d)
    {
        s+=(phrase[d]==phrase[d+1]);
    }
    d=0;
    if (s>0)
    {
      while (x<(n+10))
    {

        if (phrase[i]==phrase[i+1])
        {
            i+=2;
            inst[j]=phrase[i];
            for(i+=1;i<n;++i)
            {
                j+=1;
                inst[j]=phrase[i];
            }
            for(m=0;m<n;++m)
            {
                phrase[m]=inst[m];
            }
            m=0;
            for (q=0;q<(e-2);q++)
            {
            printf("%c",inst[q]);
            }
            printf("\n");
            i=0;
            j=0;
            q=0;
            s=0;
            for (d=0;d<(e-3);++d)
            {
              s+=(phrase[d]==phrase[d+1]);
            }
            e-=2;
            d=0;
            ++x;
            if (s==0)
              break;
        }
        else
        {
           inst[j]=phrase[i];
           i+=1;
           j+=1;
           ++x;
        }
    }
    }

return 0;
}